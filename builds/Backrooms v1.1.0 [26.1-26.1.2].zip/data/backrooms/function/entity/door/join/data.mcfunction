function backrooms:entity/door/data

tag @s add backrooms.marker.door.join